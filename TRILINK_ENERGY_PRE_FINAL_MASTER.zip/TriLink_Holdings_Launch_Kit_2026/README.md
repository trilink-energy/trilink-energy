# TriLink Holdings — 2026 Launch Kit

This package is the launch operating kit for TriLink Holdings Ltd. and its TriLink Energy division.

## Core model
Asset-light, partner-led Energy Resilience & Infrastructure for Bangladeshi commercial and industrial customers.

## Core technology
Cloudflare Pages + Cloudflare Worker + D1 + Workers AI.

## Core automation
Assessment → D1 → AI qualification → routing → customer acknowledgement → human escalation only when required.

## Important
This kit does not invent customer/project data or guarantee savings. Regulatory and legal requirements must be checked against current official guidance.
