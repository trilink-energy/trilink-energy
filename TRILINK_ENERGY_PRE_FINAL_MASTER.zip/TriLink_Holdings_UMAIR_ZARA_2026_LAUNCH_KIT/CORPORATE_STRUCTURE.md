# UMAIR-ZARA LTD — DEFINITIVE CORPORATE STRUCTURE

## Main legal company

**UMAIR-ZARA LTD**

Company number: **16789887**

All legal/company-level documentation should use the exact registered legal name:
**UMAIR-ZARA LTD**

## Operating group / brands

### TriLink Holdings
Strategic group / operating identity used for the TriLink portfolio.

### TriLink Energy
Energy Resilience & Infrastructure.

### TriLink Trade
International trade and logistics.

### Platformsify
Technology, AI and digital platforms.

### Noorva™
FMCG / private-label consumer products.

### NewM
Menswear / fashion.

## Important legal rule

Do not describe “TriLink Holdings” as a separately incorporated company unless a separate company has actually been incorporated.

Where a legal entity is required, use **UMAIR-ZARA LTD**.

Brand names and trading names should be used only in accordance with the company's actual registration, trading-name and contractual position.

## Founder / Executive Leadership

Founder / Executive Chairman / Executive Director / CEO:
**Meheraj Uddin**

The AI operating system supports management and routine operations. It does not replace legally required directors, officers, regulated professionals or authorised signatories.
