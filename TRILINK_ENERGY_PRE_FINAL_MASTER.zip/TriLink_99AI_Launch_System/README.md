# TRILINK 99% AI LAUNCH SYSTEM

This package is designed for a lean, AI-first commercial launch of TriLink Energy.

## Architecture
Chairman -> AI Command Centre -> Sales / Research / Energy / Project / Proposal / Partner / Marketing / Finance / Compliance agents -> CRM -> Website -> Qualified technical partners.

## What is already built here
- Deployable static website starter
- AI agent instruction set
- Operating SOPs
- Sales scripts
- Partner agreement heads
- Customer proposal checklist
- 100-row lead CRM CSV
- Chairman approval matrix
- Launch checklist

## What still requires account-specific connection
- Domain
- Company email
- CRM account
- AI workspace/apps
- Website hosting
- Form-to-CRM webhook
- Calendar
- Email sending
- Payment/banking
- Any external partner integrations

No credentials or secrets are included.

## 99% AI principle
AI can run research, drafting, classification, CRM updates, routine follow-up, reporting and coordination. Human/qualified professional approval remains mandatory for engineering, electrical work, safety, legal commitments, financing, banking, regulatory submissions and material contracts.

## Bangladesh launch note
Verify RJSC entity/name status and company objects before contracting. Verify applicable SREDA, utility, electrical safety and interconnection requirements for each project.

## Recommended launch order
1. Legal/name verification.
2. Set up AI workspace + CRM.
3. Deploy website.
4. Connect assessment form.
5. Load first 100 prospects.
6. Recruit/vet partners.
7. Start outreach.
8. Run first assessment.
9. Validate first project technically.
10. Close Project #001.
