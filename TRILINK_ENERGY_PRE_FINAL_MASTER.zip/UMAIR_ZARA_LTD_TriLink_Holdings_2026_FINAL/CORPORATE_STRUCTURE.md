# UMAIR-ZARA LTD — DEFINITIVE CORPORATE STRUCTURE

## Main legal company
**UMAIR-ZARA LTD**
Company number: **16789887**

Use the exact legal name **UMAIR-ZARA LTD** in legal/company documentation.

## Operating group / brands
- **TriLink Holdings** — strategic group / operating identity
- **TriLink Energy** — Energy Resilience & Infrastructure
- **TriLink Trade** — International Trade & Logistics
- **Platformsify** — AI / Technology / Digital Platforms
- **Noorva™** — FMCG / Private Label
- **NewM** — Menswear / Fashion

## Legal identity rule
Do not describe TriLink Holdings as a separate incorporated company unless a separate company is actually incorporated. Use UMAIR-ZARA LTD when a legal entity is required.

## Executive leadership
Founder / Executive Chairman / Executive Director / CEO:
**Meheraj Uddin**

AI supports management and routine operations. It does not replace legally required directors, officers, regulated professionals or authorised signatories.
